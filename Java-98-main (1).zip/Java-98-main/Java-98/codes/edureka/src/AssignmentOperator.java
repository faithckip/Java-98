
public class AssignmentOperator {

	public static void main(String[] args) {
		int n = 5;
		n *= n += 10;
		System.out.println(n);
	}

}
