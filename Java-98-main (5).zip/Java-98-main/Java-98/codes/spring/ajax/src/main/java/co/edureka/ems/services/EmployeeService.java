package co.edureka.ems.services;

import co.edureka.ems.dto.Employee;

public interface EmployeeService {

	Employee searchEmployeeByNo(int eno);
}
