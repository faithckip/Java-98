/*
  program to display a welcome message
  Author: Sunil @ edureka
  Date: 25th March 2023
*/

class Welcome
{
  public static void main(String[] args)
  {
     System.out.println("Welcome to Java Programming");
  }
}