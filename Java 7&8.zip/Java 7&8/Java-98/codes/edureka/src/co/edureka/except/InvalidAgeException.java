package co.edureka.except;

public class InvalidAgeException extends Exception {

	public InvalidAgeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidAgeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
