package co.edureka.pack1;

public class Nums {
	public int add(int x, int y) {
		return x+y;
	}
}
