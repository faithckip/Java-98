
public class BooleanType {

	public static void main(String[] args) {
		int x = 10;
		int y = 5;

		boolean result = x > y;
		System.out.println(result);
		
		y = 25;
		result = x > y;
		System.out.println(result);
	}

}
